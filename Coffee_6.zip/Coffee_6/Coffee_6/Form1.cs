﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Coffee_6
{
    public partial class From1 : Form
    {


        public From1()
        {
            InitializeComponent();
        }

        private void From1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn có thật sự muốn thoát chương trình không?", "Thông Báo", MessageBoxButtons.OKCancel) != System.Windows.Forms.DialogResult.OK)
            { e.Cancel = true; }
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void btn1_Click(object sender, EventArgs e)
        {
            string Query1 = "SELECT * FROM Account WHERE Username = '"+txt1.Text+ "' AND Pass = '"+txt2.Text+"'";
            DataTable dt = new DataTable();
            dt = ConnectSQL.Load(Query1);
            if (dt.Rows.Count > 0)
            {
                MessageBox.Show("Đăng nhập thành công");
                quanly form = new quanly();
                this.Hide();
                form.ShowDialog();
                this.Show();
                txt1.Text = "";
                txt2.Text = "";
            }    
            else
            {
                MessageBox.Show("Sai tài khoản hoặc mật khẩu");
                return;
            }    
        }
        private void From1_Load(object sender, EventArgs e)
        {

        }
       
    }
}

      
    
