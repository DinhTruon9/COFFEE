﻿namespace Coffee_6
{
    partial class fAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tablemenu = new System.Windows.Forms.TabControl();
            this.tabBill = new System.Windows.Forms.TabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnthongke = new System.Windows.Forms.Button();
            this.dateTimePicker4 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dataDoanhThu = new System.Windows.Forms.DataGridView();
            this.tabFood = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txttim = new System.Windows.Forms.TextBox();
            this.btntim = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnxem = new System.Windows.Forms.Button();
            this.btnsua = new System.Windows.Forms.Button();
            this.btnxoa = new System.Windows.Forms.Button();
            this.btnthem = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.numgia = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.combodanhmuc = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtTenMon = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataThucAn = new System.Windows.Forms.DataGridView();
            this.tabdanhmuc = new System.Windows.Forms.TabPage();
            this.panel10 = new System.Windows.Forms.Panel();
            this.txttendanhmuc = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtiddanhmuc = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btnxemdanhmuc = new System.Windows.Forms.Button();
            this.btnsuadanhmuc = new System.Windows.Forms.Button();
            this.btnxoadanhmuc = new System.Windows.Forms.Button();
            this.btnthemdanhmuc = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.datadanhmuc = new System.Windows.Forms.DataGridView();
            this.tabban = new System.Windows.Forms.TabPage();
            this.panel12 = new System.Windows.Forms.Panel();
            this.txttrangthai = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txttenban = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.btnxemban = new System.Windows.Forms.Button();
            this.btnsuaban = new System.Windows.Forms.Button();
            this.btnxoaban = new System.Windows.Forms.Button();
            this.btnthemban = new System.Windows.Forms.Button();
            this.panel14 = new System.Windows.Forms.Panel();
            this.dataBanAn = new System.Windows.Forms.DataGridView();
            this.tabtaikhoan = new System.Windows.Forms.TabPage();
            this.panel16 = new System.Windows.Forms.Panel();
            this.txtloaitaikhoan = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txttenhienthi = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.btnxemtaikhoan = new System.Windows.Forms.Button();
            this.btnsuataikhoan = new System.Windows.Forms.Button();
            this.btnxoataikhoan = new System.Windows.Forms.Button();
            this.btnthemtaikhoan = new System.Windows.Forms.Button();
            this.panel18 = new System.Windows.Forms.Panel();
            this.dataTaiKhoan = new System.Windows.Forms.DataGridView();
            this.tablemenu.SuspendLayout();
            this.tabBill.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataDoanhThu)).BeginInit();
            this.tabFood.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numgia)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataThucAn)).BeginInit();
            this.tabdanhmuc.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datadanhmuc)).BeginInit();
            this.tabban.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataBanAn)).BeginInit();
            this.tabtaikhoan.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataTaiKhoan)).BeginInit();
            this.SuspendLayout();
            // 
            // tablemenu
            // 
            this.tablemenu.Controls.Add(this.tabBill);
            this.tablemenu.Controls.Add(this.tabFood);
            this.tablemenu.Controls.Add(this.tabdanhmuc);
            this.tablemenu.Controls.Add(this.tabban);
            this.tablemenu.Controls.Add(this.tabtaikhoan);
            this.tablemenu.Location = new System.Drawing.Point(42, 12);
            this.tablemenu.Name = "tablemenu";
            this.tablemenu.SelectedIndex = 0;
            this.tablemenu.Size = new System.Drawing.Size(1108, 684);
            this.tablemenu.TabIndex = 0;
            // 
            // tabBill
            // 
            this.tabBill.BackColor = System.Drawing.Color.Chocolate;
            this.tabBill.Controls.Add(this.panel4);
            this.tabBill.Controls.Add(this.panel3);
            this.tabBill.Location = new System.Drawing.Point(4, 29);
            this.tabBill.Name = "tabBill";
            this.tabBill.Padding = new System.Windows.Forms.Padding(3);
            this.tabBill.Size = new System.Drawing.Size(1100, 651);
            this.tabBill.TabIndex = 0;
            this.tabBill.Text = "Doanh Thu";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btnthongke);
            this.panel4.Controls.Add(this.dateTimePicker4);
            this.panel4.Controls.Add(this.dateTimePicker3);
            this.panel4.Location = new System.Drawing.Point(103, 6);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(914, 92);
            this.panel4.TabIndex = 7;
            // 
            // btnthongke
            // 
            this.btnthongke.Location = new System.Drawing.Point(420, 30);
            this.btnthongke.Name = "btnthongke";
            this.btnthongke.Size = new System.Drawing.Size(115, 37);
            this.btnthongke.TabIndex = 5;
            this.btnthongke.Text = "Thống Kê";
            this.btnthongke.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker4
            // 
            this.dateTimePicker4.Location = new System.Drawing.Point(583, 31);
            this.dateTimePicker4.Name = "dateTimePicker4";
            this.dateTimePicker4.Size = new System.Drawing.Size(310, 26);
            this.dateTimePicker4.TabIndex = 3;
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.Location = new System.Drawing.Point(22, 31);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(343, 26);
            this.dateTimePicker3.TabIndex = 4;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.dataDoanhThu);
            this.panel3.Location = new System.Drawing.Point(43, 104);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1051, 511);
            this.panel3.TabIndex = 6;
            // 
            // dataDoanhThu
            // 
            this.dataDoanhThu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataDoanhThu.Location = new System.Drawing.Point(3, 3);
            this.dataDoanhThu.Name = "dataDoanhThu";
            this.dataDoanhThu.RowHeadersWidth = 62;
            this.dataDoanhThu.RowTemplate.Height = 28;
            this.dataDoanhThu.Size = new System.Drawing.Size(1045, 505);
            this.dataDoanhThu.TabIndex = 0;
            // 
            // tabFood
            // 
            this.tabFood.BackColor = System.Drawing.Color.Chocolate;
            this.tabFood.Controls.Add(this.panel5);
            this.tabFood.Controls.Add(this.panel6);
            this.tabFood.Controls.Add(this.panel1);
            this.tabFood.Location = new System.Drawing.Point(4, 29);
            this.tabFood.Name = "tabFood";
            this.tabFood.Padding = new System.Windows.Forms.Padding(3);
            this.tabFood.Size = new System.Drawing.Size(1100, 651);
            this.tabFood.TabIndex = 1;
            this.tabFood.Text = "Thức Ăn";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txttim);
            this.panel2.Controls.Add(this.btntim);
            this.panel2.Location = new System.Drawing.Point(7, 22);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(334, 87);
            this.panel2.TabIndex = 4;
            // 
            // txttim
            // 
            this.txttim.Location = new System.Drawing.Point(3, 33);
            this.txttim.Name = "txttim";
            this.txttim.Size = new System.Drawing.Size(251, 26);
            this.txttim.TabIndex = 5;
            // 
            // btntim
            // 
            this.btntim.Location = new System.Drawing.Point(260, 19);
            this.btntim.Name = "btntim";
            this.btntim.Size = new System.Drawing.Size(71, 54);
            this.btntim.TabIndex = 4;
            this.btntim.Text = "Tìm";
            this.btntim.UseVisualStyleBackColor = true;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.btnxem);
            this.panel5.Controls.Add(this.btnsua);
            this.panel5.Controls.Add(this.btnxoa);
            this.panel5.Controls.Add(this.btnthem);
            this.panel5.Location = new System.Drawing.Point(733, 18);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(361, 92);
            this.panel5.TabIndex = 2;
            // 
            // btnxem
            // 
            this.btnxem.Location = new System.Drawing.Point(274, 9);
            this.btnxem.Name = "btnxem";
            this.btnxem.Size = new System.Drawing.Size(84, 75);
            this.btnxem.TabIndex = 3;
            this.btnxem.Text = "Xem";
            this.btnxem.UseVisualStyleBackColor = true;
            // 
            // btnsua
            // 
            this.btnsua.Location = new System.Drawing.Point(90, 9);
            this.btnsua.Name = "btnsua";
            this.btnsua.Size = new System.Drawing.Size(84, 75);
            this.btnsua.TabIndex = 2;
            this.btnsua.Text = "Sửa";
            this.btnsua.UseVisualStyleBackColor = true;
            // 
            // btnxoa
            // 
            this.btnxoa.Location = new System.Drawing.Point(180, 9);
            this.btnxoa.Name = "btnxoa";
            this.btnxoa.Size = new System.Drawing.Size(84, 75);
            this.btnxoa.TabIndex = 1;
            this.btnxoa.Text = "Xóa";
            this.btnxoa.UseVisualStyleBackColor = true;
            // 
            // btnthem
            // 
            this.btnthem.Location = new System.Drawing.Point(0, 9);
            this.btnthem.Name = "btnthem";
            this.btnthem.Size = new System.Drawing.Size(84, 75);
            this.btnthem.TabIndex = 0;
            this.btnthem.Text = "Thêm";
            this.btnthem.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.panel2);
            this.panel6.Controls.Add(this.numgia);
            this.panel6.Controls.Add(this.label4);
            this.panel6.Controls.Add(this.combodanhmuc);
            this.panel6.Controls.Add(this.label3);
            this.panel6.Controls.Add(this.txtTenMon);
            this.panel6.Controls.Add(this.label2);
            this.panel6.Controls.Add(this.txt1);
            this.panel6.Controls.Add(this.label1);
            this.panel6.Location = new System.Drawing.Point(733, 125);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(361, 520);
            this.panel6.TabIndex = 3;
            this.panel6.Paint += new System.Windows.Forms.PaintEventHandler(this.panel6_Paint);
            // 
            // numgia
            // 
            this.numgia.Location = new System.Drawing.Point(110, 346);
            this.numgia.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.numgia.Name = "numgia";
            this.numgia.Size = new System.Drawing.Size(179, 26);
            this.numgia.TabIndex = 15;
            this.numgia.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label4.Location = new System.Drawing.Point(6, 338);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 41);
            this.label4.TabIndex = 14;
            this.label4.Text = "Giá:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // combodanhmuc
            // 
            this.combodanhmuc.FormattingEnabled = true;
            this.combodanhmuc.Location = new System.Drawing.Point(110, 270);
            this.combodanhmuc.Name = "combodanhmuc";
            this.combodanhmuc.Size = new System.Drawing.Size(190, 28);
            this.combodanhmuc.TabIndex = 13;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label3.Location = new System.Drawing.Point(5, 270);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 41);
            this.label3.TabIndex = 12;
            this.label3.Text = "Danh Mục:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTenMon
            // 
            this.txtTenMon.Location = new System.Drawing.Point(110, 198);
            this.txtTenMon.Multiline = true;
            this.txtTenMon.Name = "txtTenMon";
            this.txtTenMon.Size = new System.Drawing.Size(248, 41);
            this.txtTenMon.TabIndex = 11;
            this.txtTenMon.UseWaitCursor = true;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label2.Location = new System.Drawing.Point(6, 198);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 41);
            this.label2.TabIndex = 10;
            this.label2.Text = "Tên Món:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txt1
            // 
            this.txt1.Location = new System.Drawing.Point(110, 130);
            this.txt1.Multiline = true;
            this.txt1.Name = "txt1";
            this.txt1.ReadOnly = true;
            this.txt1.Size = new System.Drawing.Size(248, 41);
            this.txt1.TabIndex = 9;
            this.txt1.UseWaitCursor = true;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label1.Location = new System.Drawing.Point(6, 130);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 41);
            this.label1.TabIndex = 8;
            this.label1.Text = "ID:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dataThucAn);
            this.panel1.Location = new System.Drawing.Point(0, 6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(727, 639);
            this.panel1.TabIndex = 0;
            // 
            // dataThucAn
            // 
            this.dataThucAn.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataThucAn.Location = new System.Drawing.Point(3, 3);
            this.dataThucAn.Name = "dataThucAn";
            this.dataThucAn.RowHeadersWidth = 62;
            this.dataThucAn.RowTemplate.Height = 28;
            this.dataThucAn.Size = new System.Drawing.Size(721, 633);
            this.dataThucAn.TabIndex = 0;
            // 
            // tabdanhmuc
            // 
            this.tabdanhmuc.BackColor = System.Drawing.Color.Chocolate;
            this.tabdanhmuc.Controls.Add(this.panel10);
            this.tabdanhmuc.Controls.Add(this.panel7);
            this.tabdanhmuc.Controls.Add(this.panel8);
            this.tabdanhmuc.Location = new System.Drawing.Point(4, 29);
            this.tabdanhmuc.Name = "tabdanhmuc";
            this.tabdanhmuc.Padding = new System.Windows.Forms.Padding(3);
            this.tabdanhmuc.Size = new System.Drawing.Size(1100, 651);
            this.tabdanhmuc.TabIndex = 2;
            this.tabdanhmuc.Text = "Danh Mục";
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.txttendanhmuc);
            this.panel10.Controls.Add(this.label7);
            this.panel10.Controls.Add(this.txtiddanhmuc);
            this.panel10.Controls.Add(this.label8);
            this.panel10.Location = new System.Drawing.Point(704, 98);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(390, 119);
            this.panel10.TabIndex = 5;
            // 
            // txttendanhmuc
            // 
            this.txttendanhmuc.Location = new System.Drawing.Point(109, 71);
            this.txttendanhmuc.Multiline = true;
            this.txttendanhmuc.Name = "txttendanhmuc";
            this.txttendanhmuc.Size = new System.Drawing.Size(248, 41);
            this.txttendanhmuc.TabIndex = 11;
            this.txttendanhmuc.UseWaitCursor = true;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label7.Location = new System.Drawing.Point(6, 71);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(97, 41);
            this.label7.TabIndex = 10;
            this.label7.Text = "Tên Danh Mục:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtiddanhmuc
            // 
            this.txtiddanhmuc.Location = new System.Drawing.Point(109, 3);
            this.txtiddanhmuc.Multiline = true;
            this.txtiddanhmuc.Name = "txtiddanhmuc";
            this.txtiddanhmuc.ReadOnly = true;
            this.txtiddanhmuc.Size = new System.Drawing.Size(248, 41);
            this.txtiddanhmuc.TabIndex = 9;
            this.txtiddanhmuc.UseWaitCursor = true;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label8.Location = new System.Drawing.Point(6, 3);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(97, 41);
            this.label8.TabIndex = 8;
            this.label8.Text = "ID:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.btnxemdanhmuc);
            this.panel7.Controls.Add(this.btnsuadanhmuc);
            this.panel7.Controls.Add(this.btnxoadanhmuc);
            this.panel7.Controls.Add(this.btnthemdanhmuc);
            this.panel7.Location = new System.Drawing.Point(704, 6);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(390, 86);
            this.panel7.TabIndex = 4;
            // 
            // btnxemdanhmuc
            // 
            this.btnxemdanhmuc.Location = new System.Drawing.Point(273, 8);
            this.btnxemdanhmuc.Name = "btnxemdanhmuc";
            this.btnxemdanhmuc.Size = new System.Drawing.Size(84, 75);
            this.btnxemdanhmuc.TabIndex = 3;
            this.btnxemdanhmuc.Text = "Xem";
            this.btnxemdanhmuc.UseVisualStyleBackColor = true;
            // 
            // btnsuadanhmuc
            // 
            this.btnsuadanhmuc.Location = new System.Drawing.Point(93, 8);
            this.btnsuadanhmuc.Name = "btnsuadanhmuc";
            this.btnsuadanhmuc.Size = new System.Drawing.Size(84, 75);
            this.btnsuadanhmuc.TabIndex = 2;
            this.btnsuadanhmuc.Text = "Sửa";
            this.btnsuadanhmuc.UseVisualStyleBackColor = true;
            // 
            // btnxoadanhmuc
            // 
            this.btnxoadanhmuc.Location = new System.Drawing.Point(183, 8);
            this.btnxoadanhmuc.Name = "btnxoadanhmuc";
            this.btnxoadanhmuc.Size = new System.Drawing.Size(84, 75);
            this.btnxoadanhmuc.TabIndex = 1;
            this.btnxoadanhmuc.Text = "Xóa";
            this.btnxoadanhmuc.UseVisualStyleBackColor = true;
            // 
            // btnthemdanhmuc
            // 
            this.btnthemdanhmuc.Location = new System.Drawing.Point(3, 8);
            this.btnthemdanhmuc.Name = "btnthemdanhmuc";
            this.btnthemdanhmuc.Size = new System.Drawing.Size(84, 75);
            this.btnthemdanhmuc.TabIndex = 0;
            this.btnthemdanhmuc.Text = "Thêm";
            this.btnthemdanhmuc.UseVisualStyleBackColor = true;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.datadanhmuc);
            this.panel8.Location = new System.Drawing.Point(6, 14);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(692, 631);
            this.panel8.TabIndex = 3;
            // 
            // datadanhmuc
            // 
            this.datadanhmuc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datadanhmuc.Location = new System.Drawing.Point(3, 3);
            this.datadanhmuc.Name = "datadanhmuc";
            this.datadanhmuc.RowHeadersWidth = 62;
            this.datadanhmuc.RowTemplate.Height = 28;
            this.datadanhmuc.Size = new System.Drawing.Size(686, 628);
            this.datadanhmuc.TabIndex = 0;
            this.datadanhmuc.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datadanhmuc_CellContentClick);
            // 
            // tabban
            // 
            this.tabban.BackColor = System.Drawing.Color.Chocolate;
            this.tabban.Controls.Add(this.panel12);
            this.tabban.Controls.Add(this.panel13);
            this.tabban.Controls.Add(this.panel14);
            this.tabban.Location = new System.Drawing.Point(4, 29);
            this.tabban.Name = "tabban";
            this.tabban.Padding = new System.Windows.Forms.Padding(3);
            this.tabban.Size = new System.Drawing.Size(1100, 651);
            this.tabban.TabIndex = 3;
            this.tabban.Text = "Bàn ăn";
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.txttrangthai);
            this.panel12.Controls.Add(this.label9);
            this.panel12.Controls.Add(this.txttenban);
            this.panel12.Controls.Add(this.label5);
            this.panel12.Controls.Add(this.textBox2);
            this.panel12.Controls.Add(this.label6);
            this.panel12.Location = new System.Drawing.Point(722, 101);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(372, 196);
            this.panel12.TabIndex = 9;
            // 
            // txttrangthai
            // 
            this.txttrangthai.Location = new System.Drawing.Point(108, 146);
            this.txttrangthai.Multiline = true;
            this.txttrangthai.Name = "txttrangthai";
            this.txttrangthai.Size = new System.Drawing.Size(248, 41);
            this.txttrangthai.TabIndex = 13;
            this.txttrangthai.UseWaitCursor = true;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label9.Location = new System.Drawing.Point(4, 146);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(98, 41);
            this.label9.TabIndex = 12;
            this.label9.Text = "Trạng Thái:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txttenban
            // 
            this.txttenban.Location = new System.Drawing.Point(108, 71);
            this.txttenban.Multiline = true;
            this.txttenban.Name = "txttenban";
            this.txttenban.Size = new System.Drawing.Size(248, 41);
            this.txttenban.TabIndex = 11;
            this.txttenban.UseWaitCursor = true;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label5.Location = new System.Drawing.Point(4, 71);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 41);
            this.label5.TabIndex = 10;
            this.label5.Text = "Tên Bàn:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(108, 3);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(248, 41);
            this.textBox2.TabIndex = 9;
            this.textBox2.UseWaitCursor = true;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label6.Location = new System.Drawing.Point(4, 3);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(98, 41);
            this.label6.TabIndex = 8;
            this.label6.Text = "ID:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.btnxemban);
            this.panel13.Controls.Add(this.btnsuaban);
            this.panel13.Controls.Add(this.btnxoaban);
            this.panel13.Controls.Add(this.btnthemban);
            this.panel13.Location = new System.Drawing.Point(715, 6);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(379, 92);
            this.panel13.TabIndex = 8;
            // 
            // btnxemban
            // 
            this.btnxemban.Location = new System.Drawing.Point(285, 10);
            this.btnxemban.Name = "btnxemban";
            this.btnxemban.Size = new System.Drawing.Size(84, 75);
            this.btnxemban.TabIndex = 3;
            this.btnxemban.Text = "Xem";
            this.btnxemban.UseVisualStyleBackColor = true;
            // 
            // btnsuaban
            // 
            this.btnsuaban.Location = new System.Drawing.Point(105, 9);
            this.btnsuaban.Name = "btnsuaban";
            this.btnsuaban.Size = new System.Drawing.Size(84, 75);
            this.btnsuaban.TabIndex = 2;
            this.btnsuaban.Text = "Sửa";
            this.btnsuaban.UseVisualStyleBackColor = true;
            // 
            // btnxoaban
            // 
            this.btnxoaban.Location = new System.Drawing.Point(195, 9);
            this.btnxoaban.Name = "btnxoaban";
            this.btnxoaban.Size = new System.Drawing.Size(84, 75);
            this.btnxoaban.TabIndex = 1;
            this.btnxoaban.Text = "Xóa";
            this.btnxoaban.UseVisualStyleBackColor = true;
            // 
            // btnthemban
            // 
            this.btnthemban.Location = new System.Drawing.Point(15, 9);
            this.btnthemban.Name = "btnthemban";
            this.btnthemban.Size = new System.Drawing.Size(84, 75);
            this.btnthemban.TabIndex = 0;
            this.btnthemban.Text = "Thêm";
            this.btnthemban.UseVisualStyleBackColor = true;
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.dataBanAn);
            this.panel14.Location = new System.Drawing.Point(6, 6);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(703, 639);
            this.panel14.TabIndex = 7;
            // 
            // dataBanAn
            // 
            this.dataBanAn.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataBanAn.Location = new System.Drawing.Point(3, 9);
            this.dataBanAn.Name = "dataBanAn";
            this.dataBanAn.RowHeadersWidth = 62;
            this.dataBanAn.RowTemplate.Height = 28;
            this.dataBanAn.Size = new System.Drawing.Size(700, 627);
            this.dataBanAn.TabIndex = 0;
            // 
            // tabtaikhoan
            // 
            this.tabtaikhoan.BackColor = System.Drawing.Color.Chocolate;
            this.tabtaikhoan.Controls.Add(this.panel16);
            this.tabtaikhoan.Controls.Add(this.panel17);
            this.tabtaikhoan.Controls.Add(this.panel18);
            this.tabtaikhoan.Location = new System.Drawing.Point(4, 29);
            this.tabtaikhoan.Name = "tabtaikhoan";
            this.tabtaikhoan.Padding = new System.Windows.Forms.Padding(3);
            this.tabtaikhoan.Size = new System.Drawing.Size(1100, 651);
            this.tabtaikhoan.TabIndex = 4;
            this.tabtaikhoan.Text = "Tài Khoản";
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.txtloaitaikhoan);
            this.panel16.Controls.Add(this.label10);
            this.panel16.Controls.Add(this.txttenhienthi);
            this.panel16.Controls.Add(this.label11);
            this.panel16.Controls.Add(this.textBox4);
            this.panel16.Controls.Add(this.label12);
            this.panel16.Location = new System.Drawing.Point(736, 107);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(360, 219);
            this.panel16.TabIndex = 13;
            // 
            // txtloaitaikhoan
            // 
            this.txtloaitaikhoan.Location = new System.Drawing.Point(119, 163);
            this.txtloaitaikhoan.Multiline = true;
            this.txtloaitaikhoan.Name = "txtloaitaikhoan";
            this.txtloaitaikhoan.Size = new System.Drawing.Size(238, 41);
            this.txtloaitaikhoan.TabIndex = 13;
            this.txtloaitaikhoan.UseWaitCursor = true;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label10.Location = new System.Drawing.Point(0, 163);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(103, 41);
            this.label10.TabIndex = 12;
            this.label10.Text = "Loại Tài Khoản:";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txttenhienthi
            // 
            this.txttenhienthi.Location = new System.Drawing.Point(119, 88);
            this.txttenhienthi.Multiline = true;
            this.txttenhienthi.Name = "txttenhienthi";
            this.txttenhienthi.Size = new System.Drawing.Size(238, 41);
            this.txttenhienthi.TabIndex = 11;
            this.txttenhienthi.UseWaitCursor = true;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label11.Location = new System.Drawing.Point(0, 88);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(103, 41);
            this.label11.TabIndex = 10;
            this.label11.Text = "Tên Hiển Thị:";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(119, 20);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(238, 41);
            this.textBox4.TabIndex = 9;
            this.textBox4.UseWaitCursor = true;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label12.Location = new System.Drawing.Point(0, 20);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(103, 41);
            this.label12.TabIndex = 8;
            this.label12.Text = "Tên Tài Khoản:";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.btnxemtaikhoan);
            this.panel17.Controls.Add(this.btnsuataikhoan);
            this.panel17.Controls.Add(this.btnxoataikhoan);
            this.panel17.Controls.Add(this.btnthemtaikhoan);
            this.panel17.Location = new System.Drawing.Point(733, 6);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(361, 95);
            this.panel17.TabIndex = 12;
            // 
            // btnxemtaikhoan
            // 
            this.btnxemtaikhoan.Location = new System.Drawing.Point(273, 9);
            this.btnxemtaikhoan.Name = "btnxemtaikhoan";
            this.btnxemtaikhoan.Size = new System.Drawing.Size(84, 75);
            this.btnxemtaikhoan.TabIndex = 3;
            this.btnxemtaikhoan.Text = "Xem";
            this.btnxemtaikhoan.UseVisualStyleBackColor = true;
            // 
            // btnsuataikhoan
            // 
            this.btnsuataikhoan.Location = new System.Drawing.Point(93, 9);
            this.btnsuataikhoan.Name = "btnsuataikhoan";
            this.btnsuataikhoan.Size = new System.Drawing.Size(84, 75);
            this.btnsuataikhoan.TabIndex = 2;
            this.btnsuataikhoan.Text = "Sửa";
            this.btnsuataikhoan.UseVisualStyleBackColor = true;
            // 
            // btnxoataikhoan
            // 
            this.btnxoataikhoan.Location = new System.Drawing.Point(183, 9);
            this.btnxoataikhoan.Name = "btnxoataikhoan";
            this.btnxoataikhoan.Size = new System.Drawing.Size(84, 75);
            this.btnxoataikhoan.TabIndex = 1;
            this.btnxoataikhoan.Text = "Xóa";
            this.btnxoataikhoan.UseVisualStyleBackColor = true;
            // 
            // btnthemtaikhoan
            // 
            this.btnthemtaikhoan.Location = new System.Drawing.Point(3, 9);
            this.btnthemtaikhoan.Name = "btnthemtaikhoan";
            this.btnthemtaikhoan.Size = new System.Drawing.Size(84, 75);
            this.btnthemtaikhoan.TabIndex = 0;
            this.btnthemtaikhoan.Text = "Thêm";
            this.btnthemtaikhoan.UseVisualStyleBackColor = true;
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.dataTaiKhoan);
            this.panel18.Location = new System.Drawing.Point(6, 15);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(724, 630);
            this.panel18.TabIndex = 11;
            // 
            // dataTaiKhoan
            // 
            this.dataTaiKhoan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataTaiKhoan.Location = new System.Drawing.Point(3, 3);
            this.dataTaiKhoan.Name = "dataTaiKhoan";
            this.dataTaiKhoan.RowHeadersWidth = 62;
            this.dataTaiKhoan.RowTemplate.Height = 28;
            this.dataTaiKhoan.Size = new System.Drawing.Size(718, 624);
            this.dataTaiKhoan.TabIndex = 0;
            this.dataTaiKhoan.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataTaiKhoan_CellContentClick);
            // 
            // fAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Chocolate;
            this.ClientSize = new System.Drawing.Size(1186, 725);
            this.Controls.Add(this.tablemenu);
            this.Name = "fAdmin";
            this.Text = "fAdmin";
            this.tablemenu.ResumeLayout(false);
            this.tabBill.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataDoanhThu)).EndInit();
            this.tabFood.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numgia)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataThucAn)).EndInit();
            this.tabdanhmuc.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.datadanhmuc)).EndInit();
            this.tabban.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataBanAn)).EndInit();
            this.tabtaikhoan.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataTaiKhoan)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tablemenu;
        private System.Windows.Forms.TabPage tabBill;
        private System.Windows.Forms.TabPage tabFood;
        private System.Windows.Forms.TabPage tabdanhmuc;
        private System.Windows.Forms.TabPage tabban;
        private System.Windows.Forms.TabPage tabtaikhoan;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.Windows.Forms.DateTimePicker dateTimePicker4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.DataGridView dataDoanhThu;
        private System.Windows.Forms.Button btnthongke;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btntim;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btnxem;
        private System.Windows.Forms.Button btnsua;
        private System.Windows.Forms.Button btnxoa;
        private System.Windows.Forms.Button btnthem;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataThucAn;
        private System.Windows.Forms.TextBox txttim;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtTenMon;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown numgia;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox combodanhmuc;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.TextBox txttendanhmuc;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtiddanhmuc;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button btnxemdanhmuc;
        private System.Windows.Forms.Button btnsuadanhmuc;
        private System.Windows.Forms.Button btnxoadanhmuc;
        private System.Windows.Forms.Button btnthemdanhmuc;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.DataGridView datadanhmuc;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.TextBox txttrangthai;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txttenban;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Button btnxemban;
        private System.Windows.Forms.Button btnsuaban;
        private System.Windows.Forms.Button btnxoaban;
        private System.Windows.Forms.Button btnthemban;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.DataGridView dataBanAn;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.TextBox txtloaitaikhoan;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txttenhienthi;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Button btnxemtaikhoan;
        private System.Windows.Forms.Button btnsuataikhoan;
        private System.Windows.Forms.Button btnxoataikhoan;
        private System.Windows.Forms.Button btnthemtaikhoan;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.DataGridView dataTaiKhoan;
    }
}