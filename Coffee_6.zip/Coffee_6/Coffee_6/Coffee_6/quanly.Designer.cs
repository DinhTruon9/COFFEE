﻿namespace Coffee_6
{
    partial class quanly
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.listView1 = new System.Windows.Forms.ListView();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.adminToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinTàiKhoảnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinCáNhânToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đăngXuấtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.flow1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnthem = new System.Windows.Forms.Button();
            this.combo2 = new System.Windows.Forms.ComboBox();
            this.combo1 = new System.Windows.Forms.ComboBox();
            this.num1 = new System.Windows.Forms.NumericUpDown();
            this.panel3 = new System.Windows.Forms.Panel();
            this.combo3 = new System.Windows.Forms.ComboBox();
            this.num2 = new System.Windows.Forms.NumericUpDown();
            this.btngiam = new System.Windows.Forms.Button();
            this.btnchuyen = new System.Windows.Forms.Button();
            this.btntinh = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num1)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.listView1);
            this.panel1.Location = new System.Drawing.Point(760, 144);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(435, 345);
            this.panel1.TabIndex = 0;
            // 
            // listView1
            // 
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(4, 0);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(430, 342);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.adminToolStripMenuItem,
            this.thôngTinTàiKhoảnToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1206, 33);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // adminToolStripMenuItem
            // 
            this.adminToolStripMenuItem.Name = "adminToolStripMenuItem";
            this.adminToolStripMenuItem.Size = new System.Drawing.Size(81, 29);
            this.adminToolStripMenuItem.Text = "Admin";
            this.adminToolStripMenuItem.Click += new System.EventHandler(this.adminToolStripMenuItem_Click);
            // 
            // thôngTinTàiKhoảnToolStripMenuItem
            // 
            this.thôngTinTàiKhoảnToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thôngTinCáNhânToolStripMenuItem,
            this.đăngXuấtToolStripMenuItem});
            this.thôngTinTàiKhoảnToolStripMenuItem.Name = "thôngTinTàiKhoảnToolStripMenuItem";
            this.thôngTinTàiKhoảnToolStripMenuItem.Size = new System.Drawing.Size(187, 29);
            this.thôngTinTàiKhoảnToolStripMenuItem.Text = "Thông Tin Tài Khoản";
            // 
            // thôngTinCáNhânToolStripMenuItem
            // 
            this.thôngTinCáNhânToolStripMenuItem.Name = "thôngTinCáNhânToolStripMenuItem";
            this.thôngTinCáNhânToolStripMenuItem.Size = new System.Drawing.Size(265, 34);
            this.thôngTinCáNhânToolStripMenuItem.Text = "Thông Tin Cá Nhân";
            this.thôngTinCáNhânToolStripMenuItem.Click += new System.EventHandler(this.thôngTinCáNhânToolStripMenuItem_Click);
            // 
            // đăngXuấtToolStripMenuItem
            // 
            this.đăngXuấtToolStripMenuItem.Name = "đăngXuấtToolStripMenuItem";
            this.đăngXuấtToolStripMenuItem.Size = new System.Drawing.Size(265, 34);
            this.đăngXuấtToolStripMenuItem.Text = "Đăng Xuất";
            this.đăngXuấtToolStripMenuItem.Click += new System.EventHandler(this.đăngXuấtToolStripMenuItem_Click);
            // 
            // flow1
            // 
            this.flow1.Location = new System.Drawing.Point(12, 60);
            this.flow1.Name = "flow1";
            this.flow1.Size = new System.Drawing.Size(736, 607);
            this.flow1.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnthem);
            this.panel2.Controls.Add(this.combo2);
            this.panel2.Controls.Add(this.combo1);
            this.panel2.Controls.Add(this.num1);
            this.panel2.Location = new System.Drawing.Point(754, 60);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(440, 78);
            this.panel2.TabIndex = 3;
            // 
            // btnthem
            // 
            this.btnthem.Location = new System.Drawing.Point(253, 20);
            this.btnthem.Name = "btnthem";
            this.btnthem.Size = new System.Drawing.Size(106, 49);
            this.btnthem.TabIndex = 1;
            this.btnthem.Text = "Thêm Món";
            this.btnthem.UseVisualStyleBackColor = true;
            // 
            // combo2
            // 
            this.combo2.FormattingEnabled = true;
            this.combo2.Location = new System.Drawing.Point(6, 37);
            this.combo2.Name = "combo2";
            this.combo2.Size = new System.Drawing.Size(243, 28);
            this.combo2.TabIndex = 2;
            // 
            // combo1
            // 
            this.combo1.FormattingEnabled = true;
            this.combo1.Location = new System.Drawing.Point(6, 3);
            this.combo1.Name = "combo1";
            this.combo1.Size = new System.Drawing.Size(243, 28);
            this.combo1.TabIndex = 1;
            // 
            // num1
            // 
            this.num1.Location = new System.Drawing.Point(365, 32);
            this.num1.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.num1.Name = "num1";
            this.num1.Size = new System.Drawing.Size(66, 26);
            this.num1.TabIndex = 0;
            this.num1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.combo3);
            this.panel3.Controls.Add(this.num2);
            this.panel3.Controls.Add(this.btngiam);
            this.panel3.Controls.Add(this.btnchuyen);
            this.panel3.Controls.Add(this.btntinh);
            this.panel3.Location = new System.Drawing.Point(764, 495);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(434, 106);
            this.panel3.TabIndex = 4;
            // 
            // combo3
            // 
            this.combo3.FormattingEnabled = true;
            this.combo3.Location = new System.Drawing.Point(13, 66);
            this.combo3.Name = "combo3";
            this.combo3.Size = new System.Drawing.Size(106, 28);
            this.combo3.TabIndex = 3;
            // 
            // num2
            // 
            this.num2.Location = new System.Drawing.Point(170, 68);
            this.num2.Name = "num2";
            this.num2.Size = new System.Drawing.Size(113, 26);
            this.num2.TabIndex = 3;
            this.num2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btngiam
            // 
            this.btngiam.Location = new System.Drawing.Point(170, 20);
            this.btngiam.Name = "btngiam";
            this.btngiam.Size = new System.Drawing.Size(113, 38);
            this.btngiam.TabIndex = 5;
            this.btngiam.Text = "Giảm Giá";
            this.btngiam.UseVisualStyleBackColor = true;
            // 
            // btnchuyen
            // 
            this.btnchuyen.Location = new System.Drawing.Point(13, 20);
            this.btnchuyen.Name = "btnchuyen";
            this.btnchuyen.Size = new System.Drawing.Size(106, 40);
            this.btnchuyen.TabIndex = 4;
            this.btnchuyen.Text = "Chuyển Bàn";
            this.btnchuyen.UseVisualStyleBackColor = true;
            // 
            // btntinh
            // 
            this.btntinh.Location = new System.Drawing.Point(325, 3);
            this.btntinh.Name = "btntinh";
            this.btntinh.Size = new System.Drawing.Size(106, 100);
            this.btntinh.TabIndex = 3;
            this.btntinh.Text = "Thanh Toán";
            this.btntinh.UseVisualStyleBackColor = true;
            // 
            // quanly
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Chocolate;
            this.ClientSize = new System.Drawing.Size(1206, 710);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.flow1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "quanly";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Phần Mềm Quản Lý ";
            this.panel1.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.num1)).EndInit();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.num2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.FlowLayoutPanel flow1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox combo2;
        private System.Windows.Forms.ComboBox combo1;
        private System.Windows.Forms.NumericUpDown num1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ToolStripMenuItem adminToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thôngTinTàiKhoảnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thôngTinCáNhânToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đăngXuấtToolStripMenuItem;
        private System.Windows.Forms.Button btnthem;
        private System.Windows.Forms.Button btnchuyen;
        private System.Windows.Forms.Button btntinh;
        private System.Windows.Forms.ComboBox combo3;
        private System.Windows.Forms.NumericUpDown num2;
        private System.Windows.Forms.Button btngiam;
    }
}