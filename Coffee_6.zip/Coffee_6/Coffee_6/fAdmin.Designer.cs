﻿namespace Coffee_6
{
    partial class fAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabtaikhoan = new System.Windows.Forms.TabPage();
            this.panel16 = new System.Windows.Forms.Panel();
            this.txtPass = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtTaikhoan = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.btnxemtaikhoan = new System.Windows.Forms.Button();
            this.btnsuataikhoan = new System.Windows.Forms.Button();
            this.btnxoataikhoan = new System.Windows.Forms.Button();
            this.btnthemtaikhoan = new System.Windows.Forms.Button();
            this.panel18 = new System.Windows.Forms.Panel();
            this.dataTaiKhoan = new System.Windows.Forms.DataGridView();
            this.tabban = new System.Windows.Forms.TabPage();
            this.panel12 = new System.Windows.Forms.Panel();
            this.cboTrangThai = new System.Windows.Forms.ComboBox();
            this.textID = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtTenban = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.btnxemban = new System.Windows.Forms.Button();
            this.btnsuaban = new System.Windows.Forms.Button();
            this.btnxoaban = new System.Windows.Forms.Button();
            this.btnthemban = new System.Windows.Forms.Button();
            this.panel14 = new System.Windows.Forms.Panel();
            this.dgvBanan = new System.Windows.Forms.DataGridView();
            this.tabBill = new System.Windows.Forms.TabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnthongke = new System.Windows.Forms.Button();
            this.dateTimePicker4 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dataDoanhThu = new System.Windows.Forms.DataGridView();
            this.tablemenu = new System.Windows.Forms.TabControl();
            this.tabdanhmuc = new System.Windows.Forms.TabPage();
            this.txtDVT = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnSuaDM = new System.Windows.Forms.Button();
            this.btnXoaDM = new System.Windows.Forms.Button();
            this.txtGia = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtTen = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnThemDM = new System.Windows.Forms.Button();
            this.dgvdanhmuc = new System.Windows.Forms.DataGridView();
            this.tabtaikhoan.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataTaiKhoan)).BeginInit();
            this.tabban.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBanan)).BeginInit();
            this.tabBill.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataDoanhThu)).BeginInit();
            this.tablemenu.SuspendLayout();
            this.tabdanhmuc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvdanhmuc)).BeginInit();
            this.SuspendLayout();
            // 
            // tabtaikhoan
            // 
            this.tabtaikhoan.BackColor = System.Drawing.Color.Chocolate;
            this.tabtaikhoan.Controls.Add(this.panel16);
            this.tabtaikhoan.Controls.Add(this.panel17);
            this.tabtaikhoan.Controls.Add(this.panel18);
            this.tabtaikhoan.Location = new System.Drawing.Point(4, 29);
            this.tabtaikhoan.Name = "tabtaikhoan";
            this.tabtaikhoan.Padding = new System.Windows.Forms.Padding(3);
            this.tabtaikhoan.Size = new System.Drawing.Size(1115, 655);
            this.tabtaikhoan.TabIndex = 4;
            this.tabtaikhoan.Text = "Tài Khoản";
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.txtPass);
            this.panel16.Controls.Add(this.label10);
            this.panel16.Controls.Add(this.txtTaikhoan);
            this.panel16.Controls.Add(this.label11);
            this.panel16.Controls.Add(this.txtUsername);
            this.panel16.Controls.Add(this.label12);
            this.panel16.Location = new System.Drawing.Point(736, 108);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(360, 218);
            this.panel16.TabIndex = 13;
            // 
            // txtPass
            // 
            this.txtPass.Location = new System.Drawing.Point(118, 163);
            this.txtPass.Multiline = true;
            this.txtPass.Name = "txtPass";
            this.txtPass.Size = new System.Drawing.Size(238, 41);
            this.txtPass.TabIndex = 13;
            this.txtPass.UseWaitCursor = true;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label10.Location = new System.Drawing.Point(0, 163);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(104, 42);
            this.label10.TabIndex = 12;
            this.label10.Text = "Mật khẩu:";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTaikhoan
            // 
            this.txtTaikhoan.Location = new System.Drawing.Point(118, 88);
            this.txtTaikhoan.Multiline = true;
            this.txtTaikhoan.Name = "txtTaikhoan";
            this.txtTaikhoan.Size = new System.Drawing.Size(238, 41);
            this.txtTaikhoan.TabIndex = 11;
            this.txtTaikhoan.UseWaitCursor = true;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label11.Location = new System.Drawing.Point(0, 88);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(104, 42);
            this.label11.TabIndex = 10;
            this.label11.Text = "Tên Hiển Thị:";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtUsername
            // 
            this.txtUsername.Location = new System.Drawing.Point(118, 20);
            this.txtUsername.Multiline = true;
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(238, 41);
            this.txtUsername.TabIndex = 9;
            this.txtUsername.UseWaitCursor = true;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label12.Location = new System.Drawing.Point(0, 20);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(104, 42);
            this.label12.TabIndex = 8;
            this.label12.Text = "Tên Tài Khoản:";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.btnxemtaikhoan);
            this.panel17.Controls.Add(this.btnsuataikhoan);
            this.panel17.Controls.Add(this.btnxoataikhoan);
            this.panel17.Controls.Add(this.btnthemtaikhoan);
            this.panel17.Location = new System.Drawing.Point(734, 6);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(362, 95);
            this.panel17.TabIndex = 12;
            // 
            // btnxemtaikhoan
            // 
            this.btnxemtaikhoan.Location = new System.Drawing.Point(273, 9);
            this.btnxemtaikhoan.Name = "btnxemtaikhoan";
            this.btnxemtaikhoan.Size = new System.Drawing.Size(84, 75);
            this.btnxemtaikhoan.TabIndex = 3;
            this.btnxemtaikhoan.Text = "Xem";
            this.btnxemtaikhoan.UseVisualStyleBackColor = true;
            this.btnxemtaikhoan.Click += new System.EventHandler(this.btnxemtaikhoan_Click);
            // 
            // btnsuataikhoan
            // 
            this.btnsuataikhoan.Location = new System.Drawing.Point(93, 9);
            this.btnsuataikhoan.Name = "btnsuataikhoan";
            this.btnsuataikhoan.Size = new System.Drawing.Size(84, 75);
            this.btnsuataikhoan.TabIndex = 2;
            this.btnsuataikhoan.Text = "Sửa";
            this.btnsuataikhoan.UseVisualStyleBackColor = true;
            this.btnsuataikhoan.Click += new System.EventHandler(this.btnsuataikhoan_Click);
            // 
            // btnxoataikhoan
            // 
            this.btnxoataikhoan.Location = new System.Drawing.Point(183, 9);
            this.btnxoataikhoan.Name = "btnxoataikhoan";
            this.btnxoataikhoan.Size = new System.Drawing.Size(84, 75);
            this.btnxoataikhoan.TabIndex = 1;
            this.btnxoataikhoan.Text = "Xóa";
            this.btnxoataikhoan.UseVisualStyleBackColor = true;
            this.btnxoataikhoan.Click += new System.EventHandler(this.btnxoataikhoan_Click);
            // 
            // btnthemtaikhoan
            // 
            this.btnthemtaikhoan.Location = new System.Drawing.Point(3, 9);
            this.btnthemtaikhoan.Name = "btnthemtaikhoan";
            this.btnthemtaikhoan.Size = new System.Drawing.Size(84, 75);
            this.btnthemtaikhoan.TabIndex = 0;
            this.btnthemtaikhoan.Text = "Thêm";
            this.btnthemtaikhoan.UseVisualStyleBackColor = true;
            this.btnthemtaikhoan.Click += new System.EventHandler(this.btnthemtaikhoan_Click);
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.dataTaiKhoan);
            this.panel18.Location = new System.Drawing.Point(6, 15);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(724, 631);
            this.panel18.TabIndex = 11;
            // 
            // dataTaiKhoan
            // 
            this.dataTaiKhoan.AllowUserToAddRows = false;
            this.dataTaiKhoan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataTaiKhoan.Location = new System.Drawing.Point(3, 3);
            this.dataTaiKhoan.Name = "dataTaiKhoan";
            this.dataTaiKhoan.ReadOnly = true;
            this.dataTaiKhoan.RowHeadersWidth = 62;
            this.dataTaiKhoan.RowTemplate.Height = 28;
            this.dataTaiKhoan.Size = new System.Drawing.Size(718, 625);
            this.dataTaiKhoan.TabIndex = 0;
            this.dataTaiKhoan.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataTaiKhoan_CellClick);
            // 
            // tabban
            // 
            this.tabban.BackColor = System.Drawing.Color.Chocolate;
            this.tabban.Controls.Add(this.panel12);
            this.tabban.Controls.Add(this.panel13);
            this.tabban.Controls.Add(this.panel14);
            this.tabban.Location = new System.Drawing.Point(4, 29);
            this.tabban.Name = "tabban";
            this.tabban.Padding = new System.Windows.Forms.Padding(3);
            this.tabban.Size = new System.Drawing.Size(1115, 655);
            this.tabban.TabIndex = 3;
            this.tabban.Text = "Bàn ăn";
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.cboTrangThai);
            this.panel12.Controls.Add(this.textID);
            this.panel12.Controls.Add(this.label9);
            this.panel12.Controls.Add(this.txtTenban);
            this.panel12.Controls.Add(this.label5);
            this.panel12.Controls.Add(this.label6);
            this.panel12.Location = new System.Drawing.Point(722, 102);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(372, 195);
            this.panel12.TabIndex = 9;
            // 
            // cboTrangThai
            // 
            this.cboTrangThai.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTrangThai.FormattingEnabled = true;
            this.cboTrangThai.Location = new System.Drawing.Point(110, 146);
            this.cboTrangThai.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cboTrangThai.Name = "cboTrangThai";
            this.cboTrangThai.Size = new System.Drawing.Size(247, 28);
            this.cboTrangThai.TabIndex = 15;
            // 
            // textID
            // 
            this.textID.Location = new System.Drawing.Point(108, 9);
            this.textID.Multiline = true;
            this.textID.Name = "textID";
            this.textID.Size = new System.Drawing.Size(248, 41);
            this.textID.TabIndex = 14;
            this.textID.UseWaitCursor = true;
            this.textID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textID_KeyPress);
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label9.Location = new System.Drawing.Point(4, 146);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(98, 42);
            this.label9.TabIndex = 12;
            this.label9.Text = "Trạng Thái:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTenban
            // 
            this.txtTenban.Location = new System.Drawing.Point(108, 71);
            this.txtTenban.Multiline = true;
            this.txtTenban.Name = "txtTenban";
            this.txtTenban.Size = new System.Drawing.Size(248, 41);
            this.txtTenban.TabIndex = 11;
            this.txtTenban.UseWaitCursor = true;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label5.Location = new System.Drawing.Point(4, 71);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 42);
            this.label5.TabIndex = 10;
            this.label5.Text = "Tên Bàn:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label6.Location = new System.Drawing.Point(4, 3);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(98, 42);
            this.label6.TabIndex = 8;
            this.label6.Text = "ID:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.btnxemban);
            this.panel13.Controls.Add(this.btnsuaban);
            this.panel13.Controls.Add(this.btnxoaban);
            this.panel13.Controls.Add(this.btnthemban);
            this.panel13.Location = new System.Drawing.Point(716, 6);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(380, 92);
            this.panel13.TabIndex = 8;
            // 
            // btnxemban
            // 
            this.btnxemban.Location = new System.Drawing.Point(285, 9);
            this.btnxemban.Name = "btnxemban";
            this.btnxemban.Size = new System.Drawing.Size(84, 75);
            this.btnxemban.TabIndex = 3;
            this.btnxemban.Text = "Xem";
            this.btnxemban.UseVisualStyleBackColor = true;
            this.btnxemban.Click += new System.EventHandler(this.btnxemban_Click);
            // 
            // btnsuaban
            // 
            this.btnsuaban.Location = new System.Drawing.Point(105, 9);
            this.btnsuaban.Name = "btnsuaban";
            this.btnsuaban.Size = new System.Drawing.Size(84, 75);
            this.btnsuaban.TabIndex = 2;
            this.btnsuaban.Text = "Sửa";
            this.btnsuaban.UseVisualStyleBackColor = true;
            this.btnsuaban.Click += new System.EventHandler(this.btnsuaban_Click);
            // 
            // btnxoaban
            // 
            this.btnxoaban.Location = new System.Drawing.Point(195, 9);
            this.btnxoaban.Name = "btnxoaban";
            this.btnxoaban.Size = new System.Drawing.Size(84, 75);
            this.btnxoaban.TabIndex = 1;
            this.btnxoaban.Text = "Xóa";
            this.btnxoaban.UseVisualStyleBackColor = true;
            this.btnxoaban.Click += new System.EventHandler(this.btnxoaban_Click);
            // 
            // btnthemban
            // 
            this.btnthemban.Location = new System.Drawing.Point(15, 9);
            this.btnthemban.Name = "btnthemban";
            this.btnthemban.Size = new System.Drawing.Size(84, 75);
            this.btnthemban.TabIndex = 0;
            this.btnthemban.Text = "Thêm";
            this.btnthemban.UseVisualStyleBackColor = true;
            this.btnthemban.Click += new System.EventHandler(this.btnthemban_Click);
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.dgvBanan);
            this.panel14.Location = new System.Drawing.Point(6, 6);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(704, 638);
            this.panel14.TabIndex = 7;
            // 
            // dgvBanan
            // 
            this.dgvBanan.AllowUserToAddRows = false;
            this.dgvBanan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBanan.Location = new System.Drawing.Point(3, 9);
            this.dgvBanan.Name = "dgvBanan";
            this.dgvBanan.ReadOnly = true;
            this.dgvBanan.RowHeadersWidth = 62;
            this.dgvBanan.RowTemplate.Height = 28;
            this.dgvBanan.Size = new System.Drawing.Size(700, 628);
            this.dgvBanan.TabIndex = 0;
            this.dgvBanan.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvBanan_CellClick);
            // 
            // tabBill
            // 
            this.tabBill.BackColor = System.Drawing.Color.Pink;
            this.tabBill.Controls.Add(this.panel4);
            this.tabBill.Controls.Add(this.panel3);
            this.tabBill.Location = new System.Drawing.Point(4, 29);
            this.tabBill.Name = "tabBill";
            this.tabBill.Padding = new System.Windows.Forms.Padding(3);
            this.tabBill.Size = new System.Drawing.Size(1115, 655);
            this.tabBill.TabIndex = 0;
            this.tabBill.Text = "Doanh Thu";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btnthongke);
            this.panel4.Controls.Add(this.dateTimePicker4);
            this.panel4.Controls.Add(this.dateTimePicker3);
            this.panel4.Location = new System.Drawing.Point(104, 6);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(914, 92);
            this.panel4.TabIndex = 7;
            // 
            // btnthongke
            // 
            this.btnthongke.Location = new System.Drawing.Point(420, 31);
            this.btnthongke.Name = "btnthongke";
            this.btnthongke.Size = new System.Drawing.Size(116, 37);
            this.btnthongke.TabIndex = 5;
            this.btnthongke.Text = "Thống Kê";
            this.btnthongke.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker4
            // 
            this.dateTimePicker4.Location = new System.Drawing.Point(584, 31);
            this.dateTimePicker4.Name = "dateTimePicker4";
            this.dateTimePicker4.Size = new System.Drawing.Size(310, 26);
            this.dateTimePicker4.TabIndex = 3;
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.Location = new System.Drawing.Point(22, 31);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(343, 26);
            this.dateTimePicker3.TabIndex = 4;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.dataDoanhThu);
            this.panel3.Location = new System.Drawing.Point(6, 105);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1088, 511);
            this.panel3.TabIndex = 6;
            // 
            // dataDoanhThu
            // 
            this.dataDoanhThu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataDoanhThu.Location = new System.Drawing.Point(3, 6);
            this.dataDoanhThu.Name = "dataDoanhThu";
            this.dataDoanhThu.RowHeadersWidth = 62;
            this.dataDoanhThu.RowTemplate.Height = 28;
            this.dataDoanhThu.Size = new System.Drawing.Size(1082, 502);
            this.dataDoanhThu.TabIndex = 0;
            // 
            // tablemenu
            // 
            this.tablemenu.Controls.Add(this.tabBill);
            this.tablemenu.Controls.Add(this.tabdanhmuc);
            this.tablemenu.Controls.Add(this.tabban);
            this.tablemenu.Controls.Add(this.tabtaikhoan);
            this.tablemenu.Location = new System.Drawing.Point(42, 12);
            this.tablemenu.Name = "tablemenu";
            this.tablemenu.SelectedIndex = 0;
            this.tablemenu.Size = new System.Drawing.Size(1123, 688);
            this.tablemenu.TabIndex = 0;
            // 
            // tabdanhmuc
            // 
            this.tabdanhmuc.BackColor = System.Drawing.Color.Chocolate;
            this.tabdanhmuc.Controls.Add(this.txtDVT);
            this.tabdanhmuc.Controls.Add(this.label4);
            this.tabdanhmuc.Controls.Add(this.btnSuaDM);
            this.tabdanhmuc.Controls.Add(this.btnXoaDM);
            this.tabdanhmuc.Controls.Add(this.txtGia);
            this.tabdanhmuc.Controls.Add(this.label3);
            this.tabdanhmuc.Controls.Add(this.txtTen);
            this.tabdanhmuc.Controls.Add(this.label2);
            this.tabdanhmuc.Controls.Add(this.txtID);
            this.tabdanhmuc.Controls.Add(this.label1);
            this.tabdanhmuc.Controls.Add(this.btnThemDM);
            this.tabdanhmuc.Controls.Add(this.dgvdanhmuc);
            this.tabdanhmuc.Location = new System.Drawing.Point(4, 29);
            this.tabdanhmuc.Name = "tabdanhmuc";
            this.tabdanhmuc.Padding = new System.Windows.Forms.Padding(3);
            this.tabdanhmuc.Size = new System.Drawing.Size(1115, 655);
            this.tabdanhmuc.TabIndex = 2;
            this.tabdanhmuc.Text = "Danh Mục";
            // 
            // txtDVT
            // 
            this.txtDVT.Location = new System.Drawing.Point(812, 140);
            this.txtDVT.Multiline = true;
            this.txtDVT.Name = "txtDVT";
            this.txtDVT.Size = new System.Drawing.Size(271, 42);
            this.txtDVT.TabIndex = 12;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(678, 143);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(128, 38);
            this.label4.TabIndex = 11;
            this.label4.Text = "Đơn vị tính";
            // 
            // btnSuaDM
            // 
            this.btnSuaDM.Location = new System.Drawing.Point(854, 246);
            this.btnSuaDM.Name = "btnSuaDM";
            this.btnSuaDM.Size = new System.Drawing.Size(87, 57);
            this.btnSuaDM.TabIndex = 9;
            this.btnSuaDM.Text = "Sửa";
            this.btnSuaDM.UseVisualStyleBackColor = true;
            this.btnSuaDM.Click += new System.EventHandler(this.btnSuaDM_Click);
            // 
            // btnXoaDM
            // 
            this.btnXoaDM.Location = new System.Drawing.Point(968, 246);
            this.btnXoaDM.Name = "btnXoaDM";
            this.btnXoaDM.Size = new System.Drawing.Size(86, 57);
            this.btnXoaDM.TabIndex = 8;
            this.btnXoaDM.Text = "Xóa";
            this.btnXoaDM.UseVisualStyleBackColor = true;
            this.btnXoaDM.Click += new System.EventHandler(this.btnXoaDM_Click);
            // 
            // txtGia
            // 
            this.txtGia.Location = new System.Drawing.Point(812, 188);
            this.txtGia.Multiline = true;
            this.txtGia.Name = "txtGia";
            this.txtGia.Size = new System.Drawing.Size(271, 42);
            this.txtGia.TabIndex = 7;
            this.txtGia.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGia_KeyPress);
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(678, 191);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(128, 38);
            this.label3.TabIndex = 6;
            this.label3.Text = "Giá";
            // 
            // txtTen
            // 
            this.txtTen.Location = new System.Drawing.Point(812, 92);
            this.txtTen.Multiline = true;
            this.txtTen.Name = "txtTen";
            this.txtTen.Size = new System.Drawing.Size(271, 42);
            this.txtTen.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(664, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 38);
            this.label2.TabIndex = 4;
            this.label2.Text = "Tên hàng";
            // 
            // txtID
            // 
            this.txtID.Location = new System.Drawing.Point(812, 45);
            this.txtID.Multiline = true;
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(271, 42);
            this.txtID.TabIndex = 3;
            this.txtID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtID_KeyPress);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(678, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 38);
            this.label1.TabIndex = 2;
            this.label1.Text = "ID:";
            // 
            // btnThemDM
            // 
            this.btnThemDM.Location = new System.Drawing.Point(746, 246);
            this.btnThemDM.Name = "btnThemDM";
            this.btnThemDM.Size = new System.Drawing.Size(84, 57);
            this.btnThemDM.TabIndex = 1;
            this.btnThemDM.Text = "Thêm";
            this.btnThemDM.UseVisualStyleBackColor = true;
            this.btnThemDM.Click += new System.EventHandler(this.btnThemDM_Click);
            // 
            // dgvdanhmuc
            // 
            this.dgvdanhmuc.AllowUserToAddRows = false;
            this.dgvdanhmuc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvdanhmuc.Location = new System.Drawing.Point(6, 6);
            this.dgvdanhmuc.Name = "dgvdanhmuc";
            this.dgvdanhmuc.ReadOnly = true;
            this.dgvdanhmuc.RowHeadersWidth = 62;
            this.dgvdanhmuc.RowTemplate.Height = 28;
            this.dgvdanhmuc.Size = new System.Drawing.Size(652, 638);
            this.dgvdanhmuc.TabIndex = 0;
            this.dgvdanhmuc.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvdanhmuc_CellClick);
            // 
            // fAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Pink;
            this.ClientSize = new System.Drawing.Size(1220, 725);
            this.Controls.Add(this.tablemenu);
            this.Name = "fAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "fAdmin";
            this.Load += new System.EventHandler(this.fAdmin_Load);
            this.tabtaikhoan.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataTaiKhoan)).EndInit();
            this.tabban.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvBanan)).EndInit();
            this.tabBill.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataDoanhThu)).EndInit();
            this.tablemenu.ResumeLayout(false);
            this.tabdanhmuc.ResumeLayout(false);
            this.tabdanhmuc.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvdanhmuc)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabtaikhoan;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.TextBox txtPass;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtTaikhoan;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Button btnxemtaikhoan;
        private System.Windows.Forms.Button btnsuataikhoan;
        private System.Windows.Forms.Button btnxoataikhoan;
        private System.Windows.Forms.Button btnthemtaikhoan;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.DataGridView dataTaiKhoan;
        private System.Windows.Forms.TabPage tabban;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtTenban;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Button btnxemban;
        private System.Windows.Forms.Button btnsuaban;
        private System.Windows.Forms.Button btnxoaban;
        private System.Windows.Forms.Button btnthemban;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.DataGridView dgvBanan;
        private System.Windows.Forms.TabPage tabBill;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnthongke;
        private System.Windows.Forms.DateTimePicker dateTimePicker4;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView dataDoanhThu;
        private System.Windows.Forms.TabControl tablemenu;
        private System.Windows.Forms.TabPage tabdanhmuc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnThemDM;
        private System.Windows.Forms.DataGridView dgvdanhmuc;
        private System.Windows.Forms.Button btnSuaDM;
        private System.Windows.Forms.Button btnXoaDM;
        private System.Windows.Forms.TextBox txtGia;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtTen;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtDVT;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textID;
        private System.Windows.Forms.ComboBox cboTrangThai;
        private System.Windows.Forms.TextBox txtID;
    }
}