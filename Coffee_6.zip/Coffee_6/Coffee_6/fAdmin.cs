﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Coffee_6
{
    public partial class fAdmin : Form
    {
        public fAdmin()
        {
            InitializeComponent();
            LoadAccountList();
            DSMH();
            dgvdanhmuc.Columns["IDMon"].HeaderText = "Mã Hàng";
            dgvdanhmuc.Columns["Tenmon"].HeaderText = "Tên Hàng";
            dgvdanhmuc.Columns["Gia"].HeaderText = "Giá";
            dgvdanhmuc.Columns["DVT"].HeaderText = "ĐVT";
            
            DSBAN();
            dgvBanan.Columns["idBan"].HeaderText = "ID Bàn";
            dgvBanan.Columns["Tenban"].HeaderText = "Tên Bàn";
            dgvBanan.Columns["Trangthai"].HeaderText = "Trạng Thái";
        }
       

        void LoadAccountList()   // hiển thị danh sách tài khoản
        {
            string query1 = "Select * from dbo.Account";
            DataTable db = new DataTable();
            db = ConnectSQL.Load(query1);
            dataTaiKhoan.DataSource = db;
            dataTaiKhoan.Columns[0].AutoSizeMode =
       DataGridViewAutoSizeColumnMode.AllCells;
            dataTaiKhoan.Columns[1].AutoSizeMode =
         DataGridViewAutoSizeColumnMode.AllCells;
            dataTaiKhoan.Columns[2].AutoSizeMode =
         DataGridViewAutoSizeColumnMode.Fill;
            dataTaiKhoan.Columns[0].HeaderText = "Tên tài khoản";
            dataTaiKhoan.Columns[1].HeaderText = "Tên hiển thị";
            dataTaiKhoan.Columns[2].HeaderText = "Mật khẩu";
            if (dataTaiKhoan.Rows.Count == 0)
            {
                txtUsername.Text = "";
                txtTaikhoan.Text = "";
                txtPass.Text = "";
            }
            else
            {
                var row = this.dataTaiKhoan.Rows[0];
                txtUsername.Text = row.Cells[0].Value.ToString();
                txtTaikhoan.Text = row.Cells[1].Value.ToString();
                txtPass.Text = row.Cells[2].Value.ToString();
            }


        }
        // Phần danh mục
        private void DSMH()   // hiển thị danh sách mặt hàng trong danh mục 
        {
            string query1 = "select*from DanhMuc";
            DataTable db = new DataTable();
            db = ConnectSQL.Load(query1);
            dgvdanhmuc.DataSource = db;
            dgvdanhmuc.Columns[0].AutoSizeMode =
          DataGridViewAutoSizeColumnMode.AllCells;
            dgvdanhmuc.Columns[1].AutoSizeMode =
         DataGridViewAutoSizeColumnMode.AllCells;
            dgvdanhmuc.Columns[2].AutoSizeMode =
         DataGridViewAutoSizeColumnMode.AllCells;
            dgvdanhmuc.Columns[0].AutoSizeMode =
         DataGridViewAutoSizeColumnMode.AllCells;
            dgvdanhmuc.Columns[0].AutoSizeMode =
             DataGridViewAutoSizeColumnMode.Fill;
            if (dgvdanhmuc.Rows.Count == 0)
            {
                txtID.Text = "";
                txtTen.Text = "";
                txtDVT.Text = "";
                txtGia.Text = "";
            }
            else
            {
                var row = this.dgvdanhmuc.Rows[0];
                txtID.Text = row.Cells[0].Value.ToString();
                txtTen.Text = row.Cells[1].Value.ToString();
                txtDVT.Text = row.Cells[2].Value.ToString();
                txtGia.Text = row.Cells[3].Value.ToString();
            }
        }

        private void btnThemDM_Click(object sender, EventArgs e)
        {
            if (txtID.Text == "")
            {
                MessageBox.Show("Chưa nhập ID");
                txtID.Select();
                return;
            }
            if (txtTen.Text == "")
            {
                MessageBox.Show("Chưa nhập Tên món");
                txtTen.Select();
                return;
            }
            if (txtDVT.Text == "")
            {
                MessageBox.Show("Chưa nhập đvt");
                txtDVT.Select();
                return;
            }
            if (txtGia.Text == "")
            {
                MessageBox.Show("Chưa nhập giá");
                txtGia.Select();
                return;
            }
            //Kiểm tra trùng 
            string s = "SELECT * FROM DanhMuc WHERE IDMon = '" + txtID.Text + "'";
            DataTable d = new DataTable();
            d = ConnectSQL.Load(s);
            if (d.Rows.Count > 0)
            {
                MessageBox.Show("ID món đã tồn tại, vui lòng tạo ID khác");
                return;
            }

            string query1 = "insert into DanhMuc values (" +
                txtID.Text + ",N'" +
                txtTen.Text + "',N'" +
                txtDVT.Text + "'," +
                txtGia.Text + ")";
            ConnectSQL.ExecuteNonQuery(query1);
            MessageBox.Show("Đã thêm món "+ txtTen.Text + " vào danh mục");
            DSMH();
        }

        private void btnSuaDM_Click(object sender, EventArgs e)
        {
            if(dgvdanhmuc.Rows.Count ==0)
            {
                return;
            }    
            if (txtID.Text == "")
            {
                MessageBox.Show("Chưa nhập ID");
                txtID.Select();
                return;
            }
            if (txtTen.Text == "")
            {
                MessageBox.Show("Chưa nhập Tên món");
                txtTen.Select();
                return;
            }
            if (txtDVT.Text == "")
            {
                MessageBox.Show("Chưa nhập đvt");
                txtDVT.Select();
                return;
            }
            if (txtGia.Text == "")
            {
                MessageBox.Show("Chưa nhập giá");
                txtGia.Select();
                return;
            }
            try
            {
                string query1 = "update DanhMuc set IDMon = " +
                txtID.Text + ",Tenmon= N'" +
                txtTen.Text + "',DVT=N'" +
                txtDVT.Text + "', Gia=" +
                txtGia.Text + " WHERE IDMon = "+ dgvdanhmuc.Rows[dgvdanhmuc.CurrentCell.RowIndex].Cells[0].Value.ToString() + "";
                ConnectSQL.ExecuteNonQuery(query1);
                MessageBox.Show("Đã sửa danh mục đồ uống " + txtTen.Text);
                DSMH();
            }
            catch
            {
                MessageBox.Show("ID món đã tồn tại, vui lòng tạo ID khác");
                return;
            }
            

        } 


        private void btnXoaDM_Click(object sender, EventArgs e)
        {
            if (dgvdanhmuc.Rows.Count == 0)
            {
                return;
            }
            DialogResult dr = MessageBox.Show("Có chắc chắn xóa đồ uống này không ?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                try
                {
                    string query1 = "delete DanhMuc where IDMon=" +
                 dgvdanhmuc.Rows[dgvdanhmuc.CurrentCell.RowIndex].Cells[0].Value.ToString() + "";
                    ConnectSQL.ExecuteNonQuery(query1);
                    MessageBox.Show("Đã xóa đồ uống trong danh mục");
                    DSMH();
                }
                catch (Exception)
                {
                    MessageBox.Show("Dữ liệu đã phát sinh khóa ngoại, không xóa được");
                    return;
                }
            }
            else
                return;
        }
        // HẾT Phần danh mục
        private void DSBAN()   // hiển thị danh sách bàn ăn trong danh mục 
        {
            string query1 = "select * from Banan order by idBan";
            DataTable db = new DataTable();
            db = ConnectSQL.Load(query1);
            dgvBanan.DataSource = db;
            dgvBanan.Columns[0].AutoSizeMode =
       DataGridViewAutoSizeColumnMode.AllCells;
            dgvBanan.Columns[1].AutoSizeMode =
         DataGridViewAutoSizeColumnMode.AllCells;
            dgvBanan.Columns[2].AutoSizeMode =
         DataGridViewAutoSizeColumnMode.Fill;
            if (dgvBanan.Rows.Count == 0)
            {
                textID.Text = "";
                txtTenban.Text = "";
            }
            else
            {
                var row = this.dgvBanan.Rows[0];
                textID.Text = row.Cells[0].Value.ToString();
                txtTenban.Text = row.Cells[1].Value.ToString();
                cboTrangThai.Text = row.Cells[2].Value.ToString();
            }
        }
        private void DanhSachTrangThaiBan()
        {
            DataTable dataTable = new DataTable();
            cboTrangThai.Items.Clear();
            dataTable.Columns.Add("Name", typeof(string));
            dataTable.Rows.Add("Còn trống");
            dataTable.Rows.Add("Có khách");
            cboTrangThai.DataSource = dataTable;
            cboTrangThai.DisplayMember = "Name";
            cboTrangThai.ValueMember = "Name";
        }
        private void btnthemban_Click(object sender, EventArgs e)
        {
            if(textID.Text == "")
            {
                MessageBox.Show("Chưa nhập ID");
                textID.Select();
                return;
            }
            if (txtTenban.Text == "")
            {
                MessageBox.Show("Chưa nhập Tên bàn");
                txtTenban.Select();
                return;
            }
            //Kiểm tra trùng 
            string s = "SELECT * FROM Banan WHERE idBan = '" + textID.Text + "'";
            DataTable d = new DataTable();
            d = ConnectSQL.Load(s);
            if (d.Rows.Count > 0)
            {
                MessageBox.Show("ID bàn đã tồn tại, vui lòng tạo ID khác");
                return;
            }    
            string query1 = "insert into Banan values (" +
                textID.Text + ",N'"+
                txtTenban.Text + "',N'"+
                cboTrangThai.Text + "')";
            ConnectSQL.ExecuteNonQuery(query1);
            MessageBox.Show("Đã thêm bàn "+ txtTenban.Text+" vào danh mục");
            DSBAN();

        }

        private void btnsuaban_Click(object sender, EventArgs e)
        {
            if (dgvBanan.Rows.Count == 0)
            {
                MessageBox.Show("Chưa có dữ liệu để sửa");
                return;
            }
 
            if (textID.Text == "")
            {
                MessageBox.Show("Chưa nhập ID");
                textID.Select();
                return;
            }
            if (txtTenban.Text == "")
            {
                MessageBox.Show("Chưa nhập Tên bàn");
                txtTenban.Select();
                return;
            }
            try
            {
                string query1 = "update Banan set idBan = "+textID.Text+", Tenban =N'" +
                 txtTenban.Text + "' ,Trangthai=N'" +
                    cboTrangThai.Text + "' where idBan=" +
                dgvBanan.Rows[dgvBanan.CurrentCell.RowIndex].Cells[0].Value.ToString() + "";
                ConnectSQL.ExecuteNonQuery(query1);
                MessageBox.Show("Đã sửa bàn " + txtTenban.Text);
                DSBAN();
            }
            catch (Exception)
            {
                MessageBox.Show("ID bàn đã tồn tại, vui lòng tạo ID khác");
                return;
            }
            

        }

        private void fAdmin_Load(object sender, EventArgs e)
        {
            DanhSachTrangThaiBan();
        }

        private void textID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
                e.Handled = true;
        }

        private void dgvBanan_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvBanan.Rows[e.RowIndex];
                textID.Text = row.Cells[0].Value.ToString();
                txtTenban.Text = row.Cells[1].Value.ToString();
                cboTrangThai.Text = row.Cells[2].Value.ToString();
            }
        }

        private void btnxemban_Click(object sender, EventArgs e)
        {
            DSBAN();
        }

        private void btnxoaban_Click(object sender, EventArgs e)
        {
            if (dgvBanan.Rows.Count == 0)
            {
                return;
            }
            DialogResult dr = MessageBox.Show("Có chắc chắn xóa bàn này không ?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                try
                {
                    string query1 = "DELETE Banan where idban = "+ dgvBanan.Rows[dgvBanan.CurrentCell.RowIndex].Cells[0].Value.ToString() + "    ";
                    ConnectSQL.ExecuteNonQuery(query1);
                    MessageBox.Show("Đã xóa bàn");
                    DSBAN();
                }
                catch (Exception)
                {
                    MessageBox.Show("Dữ liệu đã phát sinh khóa ngoại, không xóa được");
                    return;
                }
            }
            else
                return;
        }

        private void txtID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
                e.Handled = true;
        }

        private void txtGia_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
                e.Handled = true;
        }

        private void dgvdanhmuc_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvdanhmuc.Rows[e.RowIndex];
                txtID.Text = row.Cells[0].Value.ToString();
                txtTen.Text = row.Cells[1].Value.ToString();
                txtDVT.Text = row.Cells[2].Value.ToString();
                txtGia.Text = row.Cells[3].Value.ToString();
            }
        }

        private void btnthemtaikhoan_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text == "")
            {
                MessageBox.Show("Chưa nhập tên tài khoản");
                txtUsername.Select();
                return;
            }
            if (txtTaikhoan.Text == "")
            {
                MessageBox.Show("Chưa nhập tên hiển thị");
                txtTaikhoan.Select();
                return;
            }
            if (txtPass.Text == "")
            {
                MessageBox.Show("Chưa nhập mật khẩu");
                txtPass.Select();
                return;
            }
            //Kiểm tra trùng 
            string s = "SELECT * FROM Account WHERE Username = '" + txtUsername.Text + "'";
            DataTable d = new DataTable();
            d = ConnectSQL.Load(s);
            if (d.Rows.Count > 0)
            {
                MessageBox.Show("Tên tài khoản đã tồn tại, vui lòng tạo tên khác");
                return;
            }
            string query1 = "insert into Account values (N'" +
                txtUsername.Text + "',N'" +
                txtTaikhoan.Text + "',N'" +
                txtPass.Text + "')";
            ConnectSQL.ExecuteNonQuery(query1);
            MessageBox.Show("Đã thêm tài khoản " + txtTaikhoan.Text + "");
            LoadAccountList();
        }

        private void btnsuataikhoan_Click(object sender, EventArgs e)
        {
            if (dataTaiKhoan.Rows.Count == 0)
            {
                MessageBox.Show("Chưa có dữ liệu để sửa");
                return;
            }
            if (txtUsername.Text == "")
            {
                MessageBox.Show("Chưa nhập tên tài khoản");
                txtUsername.Select();
                return;
            }
            if (txtTaikhoan.Text == "")
            {
                MessageBox.Show("Chưa nhập tên hiển thị");
                txtTaikhoan.Select();
                return;
            }
            if (txtPass.Text == "")
            {
                MessageBox.Show("Chưa nhập mật khẩu");
                txtPass.Select();
                return;
            }
            try
            {
                string query1 = "update Account set Username = N'" + txtUsername.Text + "', Taikhoan =N'" +
                 txtTaikhoan.Text + "' ,Pass=N'" +
                    txtPass.Text + "' where Username=" +
                dataTaiKhoan.Rows[dataTaiKhoan.CurrentCell.RowIndex].Cells[0].Value.ToString() + "";
                ConnectSQL.ExecuteNonQuery(query1);
                MessageBox.Show("Đã sửa tài khoản " + txtTenban.Text);
                LoadAccountList();
            }
            catch (Exception)
            {
                MessageBox.Show("Tên tài khoản đã tồn tại, vui lòng tạo tên khác");
                return;
            }
        }

        private void btnxoataikhoan_Click(object sender, EventArgs e)
        {
            if (dataTaiKhoan.Rows.Count == 0)
            {
                return;
            }
            DialogResult dr = MessageBox.Show("Có chắc chắn xóa tài khoản này không ?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                try
                {
                    string query1 = "DELETE Account where Username = " + dataTaiKhoan.Rows[dataTaiKhoan.CurrentCell.RowIndex].Cells[0].Value.ToString() + "    ";
                    ConnectSQL.ExecuteNonQuery(query1);
                    MessageBox.Show("Đã xóa tài khoản");
                    LoadAccountList();
                }
                catch (Exception)
                {
                    MessageBox.Show("Dữ liệu đã phát sinh khóa ngoại, không xóa được");
                    return;
                }
            }
            else
                return;
        }

        private void btnxemtaikhoan_Click(object sender, EventArgs e)
        {
            LoadAccountList();
        }

        private void dataTaiKhoan_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataTaiKhoan.Rows[e.RowIndex];
                txtUsername.Text = row.Cells[0].Value.ToString();
                txtTaikhoan.Text = row.Cells[1].Value.ToString();
                txtPass.Text = row.Cells[2].Value.ToString();
            }
        }
    }
}










